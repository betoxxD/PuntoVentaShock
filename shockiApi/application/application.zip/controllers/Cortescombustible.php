<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require( APPPATH.'/libraries/RestController.php');
require( APPPATH.'/libraries/Format.php');

use chriskacerguis\RestServer\RestController;

class Cortescombustible extends RestController {

    public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('Cortescombustible_model');
	}

	public function index_get() {
		$query = $this->db->get('cortescombustible');
		$cuantos = $this->db->count_all('cortescombustible');
		$respuesta = array(
        'err' => FALSE,
        'cuantos' => $cuantos,
        'lista' => $query->result(),
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}
	


	public function index_delete() {
		$id = $this->uri->segment(2);
		if (!isset($id)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Es necesario el ID del numero',
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta);
			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}
		$respuesta = $this->Cortescombustible_model->delete($id);
		$this->response( $respuesta );
	}

	public function index_post() {
		$data = $this->post();
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
		$result = $this->Cortescombustible_model->set_datos($data);
		$respuesta = $result->insert();

		if ($respuesta['err']) {
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		} else {
			$this->response($respuesta);
		}
		$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
	}

	public function corte_get(){
		$id = $this->uri->segment(3);

		//Validacion del numero_id
		if (!isset($id)) {
			$respuesta = array(
				'err' => true,
				'mensaje' => 'Es necesario el ID',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		$result = $this->Cortescombustible_model->get($id);

		if (isset($result)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'Registro cargado correctamente.',
				'result' => $result,
				'err_code' => 'HTTP_OK'
			);
			$this->response($respuesta);
		} else {

			$respuesta = array(
				'err' => true,
				'mensaje' => 'El registro ' . $id . ' no existe.',
				'result' => null,
				'err_code' => 'HTTP_NOT_FOUND'
			);
			$this->response($respuesta, RestController::HTTP_NOT_FOUND);
		}
	}

	/*Actuliza registro por ID*/
	public function index_put() {
        $id = $this->uri->segment(2);
		$anterior = $this->Cortescombustible_model->get($id);
		$data = $this->put();
		$data['id'] = $id;
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
			$obj = $this->Cortescombustible_model->set_datos( $data );
			$respuesta = $obj->update();
			if ($respuesta['err']) {
				$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
			} else {
				$this->response($respuesta);
			}
	}


}