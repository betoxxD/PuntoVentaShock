<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require( APPPATH.'/libraries/RestController.php');
require( APPPATH.'/libraries/Format.php');

use chriskacerguis\RestServer\RestController;

class Refacciones extends RestController {

    public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('Refacciones_model');
		$this->load->model('Proveedores_model');
	}

	public function index_get() {
		$query = $this->db->get('refacciones');
		
		$lista = $query->result();
		for ($i = 0; $i < count($lista); $i++) {
			$proveedor = $this->Proveedores_model->get($lista[$i]->id_proveedor);
			$lista[$i]->proveedor = $proveedor;
		}
		$respuesta = array(
        'err' => FALSE,
        'cuantos' => count($lista),
        'lista' => $lista,
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}
	public function byarea_get() {
		$area = $this->uri->segment(2);
		$query = $this->db->where('area', $area)->get('refacciones');
		$lista = $query->result();
		for ($i = 0; $i < count($lista); $i++) {
			$proveedor = $this->Proveedores_model->get($lista[$i]->id_proveedor);
			$lista[$i]->proveedor = $proveedor;
		}
		$respuesta = array(
        	'err' => FALSE,
        	'cuantos' => count($lista),
        	'lista' => $lista,
        	'err_code' => 'HTTP_OK'
        );
		$this->response($respuesta);
	}

	public function index_delete() {
		$id = $this->uri->segment(2);
		if (!isset($id)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Es necesario el ID del numero',
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta);
			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}
		$respuesta = $this->Refacciones_model->delete($id);
		$this->response( $respuesta );
	}

	public function index_post() {
		$data = $this->post();
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
		$result = $this->Refacciones_model->set_datos($data);
		$respuesta = $result->insert();

		if ($respuesta['err']) {
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		} else {
			$this->response($respuesta);
		}
		$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
	}

	public function refaccion_get(){
		$id = $this->uri->segment(3);

		//Validacion del numero_id
		if (!isset($id)) {
			$respuesta = array(
				'err' => true,
				'mensaje' => 'Es necesario el ID del cliente',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		$result = $this->Refacciones_model->get($id);

		if (isset($result)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'Registro cargado correctamente.',
				'result' => $result,
				'err_code' => 'HTTP_OK'
			);
			$this->response($respuesta);
		} else {

			$respuesta = array(
				'err' => true,
				'mensaje' => 'El registro ' . $id . ' no existe.',
				'result' => null,
				'err_code' => 'HTTP_NOT_FOUND'
			);
			$this->response($respuesta, RestController::HTTP_NOT_FOUND);
		}
	}

	/*Actuliza registro por ID*/
	public function index_put() {
        $id = $this->uri->segment(2);
		$anterior = $this->Refacciones_model->get($id);
		$data = $this->put();
		$data['id'] = $id;
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
			$obj = $this->Refacciones_model->set_datos( $data );
			$respuesta = $obj->update();
			if ($respuesta['err']) {
				$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
			} else {
				$this->response($respuesta);
			}
	}


}