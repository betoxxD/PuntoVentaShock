<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require( APPPATH.'/libraries/RestController.php');
require( APPPATH.'/libraries/Format.php');

use chriskacerguis\RestServer\RestController;

class Controlservicios extends RestController {

    public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('Controlservicios_model');
		$this->load->model('Notas_model');
		$this->load->model('Clientes_model');
		$this->load->model('Unidades_model');
		$this->load->model('Choferes_model');
		$this->load->model('Direcciones_model');
		
	}
	

	public function index_get() {
		$query = $this->db->get('controlservicios');
		$lista = $query->result();
		for ($i = 0 ; $i < count($lista) ; $i++) {
			$cliente = $this->Clientes_model->get($lista[$i]->id_cliente);
			$query2 = $this->db->where('id_servicio', $lista[$i]->id)->get('notas');
			$lista_notas = $query2->result();
			if (count($lista_notas) > 0) {
				$lista[$i]->nota = $lista_notas[0];
			} else {
				$lista[$i]->nota = null;
			}
			$lista[$i]->cliente = $cliente;

		}
		$respuesta = array(
        'err' => FALSE,
        'cuantos' => count($lista),
        'lista' => $lista,
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}
	public function detallecorte_post() {
		$data = $this->post();
		$condiciones = array (
			'dia_reserva' => $data['dia'],
			'tipo_corte' => $data['tipo_corte']
		);
		$query = $this->db->where($condiciones)->get('controlservicios');
		$lista = $query->result();
		for ($i = 0 ; $i < count($lista) ; $i++) {
			$cliente = $this->Clientes_model->get($lista[$i]->id_cliente);
			$lista[$i]->cliente = $cliente;
		}
		$respuesta = array(
       	 	'err' => FALSE,
	        'cuantos' => count($lista),
	        'lista' => $lista,
	        'err_code' => 'HTTP_OK'
    	);
		$this->response($respuesta);
	}

	public function bycliente_get() {
		$id = $this->uri->segment(3);
		$estado = $this->uri->segment(4);
		if (!isset($id)) {
			$respuesta = array( 'err' => true, 'mensaje' => 'Es necesario el ID del Cliente', 'err_code' => 'HTTP_BAD_REQUEST' );
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		}

		if (!is_numeric($id)) {
			$respuesta = array( 'err' => false, 'mensaje' => 'El ID debe ser numérico.', 'result' => $id, 'err_code' => 'HTTP_BAD_REQUEST' );
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		}
		if (isset($estado)) {
			
			if ($estado == '2') {
				$condiciones = array (
					'id_cliente' => $id,
					'estado' => 'Finalizado'
				);	
			} else {
				$condiciones = array ( 'id_cliente' => $id);	
			}
			
			$query = $this->db->where($condiciones)->get('controlservicios');
		} else {
			$query = $this->db->where('id_cliente', $id)->get('controlservicios');	
		}

		
		$lista = $query->result();
		for($i = 0; $i < count($lista) ; $i++) {
			$direccion = $this->Direcciones_model->get($lista[$i]->id_direccion);
			$lista[$i]->direccion = $direccion;
		}

		$respuesta = array(
        'err' => FALSE,
        'cuantos' => count($lista),
        'lista' => $lista,
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}

	public function index_delete() {
		$id = $this->uri->segment(2);
		if (!isset($id)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Es necesario el ID del numero',
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta);
			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}
		$respuesta = $this->Controlservicios_model->delete($id);
		$this->response( $respuesta );
	}

	public function index_post() {
		$data = $this->post();
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
		$result = $this->Controlservicios_model->set_datos($data);
		$respuesta = $result->insert();

		if ($respuesta['err']) {
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		} else {
			$this->response($respuesta);
		}

		$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
	}

	public function controlservicio_get(){
		$id = $this->uri->segment(3);

		//Validacion del numero_id
		if (!isset($id)) {
			$respuesta = array(
				'err' => true,
				'mensaje' => 'Es necesario el ID del Ingreso',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		$result = $this->Controlservicios_model->get($id);

		if (isset($result)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'Registro cargado correctamente.',
				'result' => $result,
				'err_code' => 'HTTP_OK'
			);
			$this->response($respuesta);
		} else {

			$respuesta = array(
				'err' => true,
				'mensaje' => 'El registro ' . $id . ' no existe.',
				'result' => null,
				'err_code' => 'HTTP_NOT_FOUND'
			);
			$this->response($respuesta, RestController::HTTP_NOT_FOUND);
		}
	}

	public function index_put() {
        $id = $this->uri->segment(2);
		$anterior = $this->Controlservicios_model->get($id);
		$data = $this->put();
		$data['id'] = $id;
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
		$obj = $this->Controlservicios_model->set_datos( $data );
		$respuesta = $obj->update();
		$respuestas = array();
		if ($respuesta['err']) {
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		} else {
			if (isset($obj->id_unidad) && isset($obj->id_chofer)) {
				if ($obj->estado == 'En proceso') {
					$unidad = $this->Unidades_model->get($obj->id_unidad);
					$unidad->accion = 'ocupado';
					$chofer = $this->Choferes_model->get($obj->id_chofer);
					$chofer->accion = 'ocupado';
					$resU = $unidad->update();
					$resC = $chofer->update();
				} else {
					$unidad = $this->Unidades_model->get($obj->id_unidad);
					$unidad->accion = 'disponible';
					$chofer = $this->Choferes_model->get($obj->id_chofer);
					$chofer->accion = 'disponible';
					$resU = $unidad->update();
					$resC = $chofer->update();
				}
				array_push($respuestas, $resU);
				array_push($respuestas, $resC);
				array_push($respuestas, $respuesta);
			}
			$this->response($respuestas);
		}
	}
	
	public function upload_post(){
		
		$data = 'entro';
		$id = $this->uri->segment(3);
		$campo = $this->uri->segment(4);
		$control = $this->Controlservicios_model->get($id);



		if (!file_exists('./uploads/control_servicios')) {
			mkdir('./uploads/control_servicios', 0755);
		}
		if (!file_exists('./uploads/control_servicios/Control-'.$id)) {
			mkdir('./uploads/control_servicios/Control-'.$id, 0755);
		}

		if(count($_FILES) > 0 ){
			$config['upload_path'] = './uploads/control_servicios/Control-'.$id;
			$config['allowed_types'] = 'gif|jpg|jpeg|png|GIF|JPG|JPEG|PNG|pdf|PDF';
			$config['max_size'] = '0' ; 
			$config['max_width'] = '0' ; 
			$config['max_height'] = '0' ;
			$this->load->library('upload', $config);
			foreach ($_FILES as $nombre => $archivo) {
				if ( ! $this->upload->do_upload($nombre)){
					$error = array('error' => $this->upload->display_errors());
					$respuesta = array(
						'err' => true,
						'mensaje' => 'Ocurrio un error al subir los archivos',
						'errors' => $error,
					);
				}
				else{
					$data = array('upload_data' => $this->upload->data());
					if(!isset($control->$campo)){
						$control->$campo= $data['upload_data']['file_name'];
					}else{
						$ant_imgs = $control->$campo;
						$control->$campo = $ant_imgs . "," . $data['upload_data']['file_name'];
					}
					$result = $control->update();
					$respuesta = array(
						'err' => false,
						'mensaje' => 'Subida de archivo correta',
						'update' => $result,
						'control' => $control,
						'err_code' => 'HTTP_OK'
					);
				}
			}

			$this->response($respuesta);
		}else{
			$this->response(array(
				'err'=> true, 
				'mensaje' => 'No selecciono ningun archivo', 
				'err_code' => 'HTTP_BAD_REQUEST'
			));
		}
	}



}