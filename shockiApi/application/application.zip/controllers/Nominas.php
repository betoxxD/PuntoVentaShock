<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require( APPPATH.'/libraries/RestController.php');
require( APPPATH.'/libraries/Format.php');

use chriskacerguis\RestServer\RestController;

class Nominas extends RestController {

    public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('Nominas_model');
	}

	public function index_get() {
		$query = $this->db->get('nominas');
		$cuantos = $this->db->count_all('nominas');
		$respuesta = array(
        'err' => FALSE,
        'cuantos' => $cuantos,
        'lista' => $query->result(),
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}
	public function byconductor_get() {
		$id = $this->uri->segment(3);
		if (!isset($id)) {
			$respuesta = array( 'err' => true, 'mensaje' => 'Es necesario el ID', 'err_code' => 'HTTP_BAD_REQUEST' );
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		}

		if (!is_numeric($id)) {
			$respuesta = array( 'err' => false, 'mensaje' => 'El ID debe ser numérico.', 'result' => $id, 'err_code' => 'HTTP_BAD_REQUEST');
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		}
		$query = $this->db->where('id_chofer', $id)->get('nominas');
		$respuesta = array(
        'err' => FALSE,
        'cuantos' => count($query->result()),
        'lista' => $query->result(),
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}


	public function index_delete() {
		$id = $this->uri->segment(2);
		if (!isset($id)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Es necesario el ID del numero',
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta);
			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}
		$respuesta = $this->Nominas_model->delete($id);
		$this->response( $respuesta );
	}

	public function index_post() {
		$data = $this->post();
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
		$result = $this->Nominas_model->set_datos($data);
		$respuesta = $result->insert();

		if ($respuesta['err']) {
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		} else {
			$this->response($respuesta);
		}
		$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
	}

	public function nomina_get(){
		$id = $this->uri->segment(3);

		//Validacion del numero_id
		if (!isset($id)) {
			$respuesta = array(
				'err' => true,
				'mensaje' => 'Es necesario el ID',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		$result = $this->Nominas_model->get($id);

		if (isset($result)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'Registro cargado correctamente.',
				'result' => $result,
				'err_code' => 'HTTP_OK'
			);
			$this->response($respuesta);
		} else {

			$respuesta = array(
				'err' => true,
				'mensaje' => 'El registro ' . $id . ' no existe.',
				'result' => null,
				'err_code' => 'HTTP_NOT_FOUND'
			);
			$this->response($respuesta, RestController::HTTP_NOT_FOUND);
		}
	}

	/*Actuliza registro por ID*/
	public function index_put() {
        $id = $this->uri->segment(2);
		$anterior = $this->Nominas_model->get($id);
		$data = $this->put();
		$data['id'] = $id;
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
			$obj = $this->Nominas_model->set_datos( $data );
			$respuesta = $obj->update();
			if ($respuesta['err']) {
				$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
			} else {
				$this->response($respuesta);
			}
	}


	public function upload_post(){
		
		$data = 'entro';
		$id = $this->uri->segment(3);
		$campo = $this->uri->segment(4);
		$nomina = $this->Nominas_model->get($id);



		if (!file_exists('./uploads/nominas')) {
			mkdir('./uploads/nominas', 0755);
		}
		if (!file_exists('./uploads/nominas/Nomina-'.$id)) {
			mkdir('./uploads/nominas/Nomina-'.$id, 0755);
		}

		if(count($_FILES) > 0 ){
			$config['upload_path'] = './uploads/nominas/Nomina-'.$id;
			$config['allowed_types'] = 'gif|jpg|jpeg|png|GIF|JPG|JPEG|PNG|pdf|PDF';
			$config['max_size'] = '0' ; 
			$config['max_width'] = '0' ; 
			$config['max_height'] = '0' ;
			$this->load->library('upload', $config);
			foreach ($_FILES as $nombre => $archivo) {
				if ( ! $this->upload->do_upload($nombre)){
					$error = array('error' => $this->upload->display_errors());
					$respuesta = array(
						'err' => true,
						'mensaje' => 'Ocurrio un error al subir los archivos',
						'errors' => $error,
					);
				}
				else{
					$data = array('upload_data' => $this->upload->data());
					if(!isset($nomina->$campo)){
						$nomina->$campo= $data['upload_data']['file_name'];
					}else{
						$ant_imgs = $nomina->$campo;
						$nomina->$campo = $ant_imgs . "," . $data['upload_data']['file_name'];
					}
					$result = $nomina->update();
					$respuesta = array(
						'err' => false,
						'mensaje' => 'Subida de archivo correta',
						'update' => $result,
						'nomina' => $nomina,
						'err_code' => 'HTTP_OK'
					);
				}
			}

			$this->response($respuesta);
		}else{
			$this->response(array(
				'err'=> true, 
				'mensaje' => 'No selecciono ningun archivo', 
				'err_code' => 'HTTP_BAD_REQUEST'
			));
		}
	}



}