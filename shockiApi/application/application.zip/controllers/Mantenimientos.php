<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require( APPPATH.'/libraries/RestController.php');
require( APPPATH.'/libraries/Format.php');

use chriskacerguis\RestServer\RestController;

class Mantenimientos extends RestController {

    public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('Mantenimientos_model');
		$this->load->model('Unidades_model');
		$this->load->model('Refacciones_model');
		$this->load->model('Proveedores_model');
		
	}
	

	public function index_get() {
		$query = $this->db->order_by('alerta_prioridades', 'ASC')->limit(50)->get('mantenimientos');
		$lista = $query->result();
		for ($i = 0; $i < count($lista); $i++) {
			$lista[$i]->proveedores = array();
			$query2 = $this->db->where('id_mantenimiento', $lista[$i]->id)->get('refaccionmantenimiento');
			$lista_refaccionmantenimiento = $query2->result();
			if (count($lista_refaccionmantenimiento) > 0) {
				for($j = 0; $j < count($lista_refaccionmantenimiento); $j++) {
					$refaccion = $this->Refacciones_model->get($lista_refaccionmantenimiento[$j]->id_refaccion);
					$proveedor = $this->Proveedores_model->get($refaccion->id_proveedor);
					array_push($lista[$i]->proveedores, $proveedor);
				}
			}
		}
		$respuesta = array(
	        'err' => FALSE,
	        'cuantos' => count($lista),
	        'lista' => $lista,
	        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}
	public function todos_post() {
		$data = $this->post();
		if (isset($data['fecha_inicial']) && $data['fecha_final']) {
			$condiciones = array(
				'fecha >=' => $data['fecha_inicial'],
				'fecha <=' => $data['fecha_final']
			);
			$query = $this->db->where($condiciones)->order_by('fecha', 'DESC')->limit(50)->get('mantenimientos');
		} else {
			$query = $this->db->order_by('fecha', 'DESC')->limit(50)->get('mantenimientos');
		}
		
		$lista = $query->result();
		for ($i = 0; $i < count($lista); $i++) {
			$lista[$i]->proveedores = array();
			$query2 = $this->db->where('id_mantenimiento', $lista[$i]->id)->get('refaccionmantenimiento');
			$lista_refaccionmantenimiento = $query2->result();
			if (count($lista_refaccionmantenimiento) > 0) {
				for($j = 0; $j < count($lista_refaccionmantenimiento); $j++) {
					$refaccion = $this->Refacciones_model->get($lista_refaccionmantenimiento[$j]->id_refaccion);
					$proveedor = $this->Proveedores_model->get($refaccion->id_proveedor);
					array_push($lista[$i]->proveedores, $proveedor);
				}
			}
		}
		$respuesta = array(
	        'err' => FALSE,
	        'cuantos' => count($lista),
	        'lista' => $lista,
	        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}


	public function porunidad_post() {
		$id = $this->uri->segment(3);
		$data = $this->post();
		if (isset($data['fecha_inicial']) && $data['fecha_final']) {
			$condiciones = array(
				'id_unidad' => $id,
				'fecha >=' => $data['fecha_inicial'],
				'fecha <=' => $data['fecha_final']
			);
			$query = $this->db->where($condiciones)->order_by('fecha', 'DESC')->get('mantenimientos');
		} else {
		$query = $this->db->where('id_unidad', $id)->order_by('fecha', 'DESC')->get('mantenimientos');	
		}
		
		$lista = $query->result();
		for ($i = 0; $i < count($lista); $i++) {
			$lista[$i]->proveedores = array();
			$query2 = $this->db->where('id_mantenimiento', $lista[$i]->id)->get('refaccionmantenimiento');
			$lista_refaccionmantenimiento = $query2->result();
			if (count($lista_refaccionmantenimiento) > 0) {
				for($j = 0; $j < count($lista_refaccionmantenimiento); $j++) {
					$refaccion = $this->Refacciones_model->get($lista_refaccionmantenimiento[$j]->id_refaccion);
					$proveedor = $this->Proveedores_model->get($refaccion->id_proveedor);
					array_push($lista[$i]->proveedores, $proveedor);
				}
			}
		}
		$respuesta = array(
        'err' => FALSE,
        'cuantos' => count($lista),
        'lista' => $lista,
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}
	
	public function porchofer_get() {
		$id = $this->uri->segment(3);
		$condiciones = array(
			'id_solicitante' => $id,
			'tipo_solicitante' => 'chofer'
		);
		$query = $this->db->where($condiciones)->order_by('fecha', 'DESC')->get('mantenimientos');
		$respuesta = array(
        'err' => FALSE,
        'cuantos' => count($query->result()),
        'lista' => $query->result(),
        'err_code' => 'HTTP_OK');
		$this->response($respuesta);
	}
	public function byproveedor_post() {
		$data = $this->post();
		$id = $this->uri->segment(3);
		$proveedor = $this->Proveedores_model->get($id);
		$query = $this->db->where('id_proveedor', $id)->get('refacciones');
		$lista_refacciones = $query->result();

		$ids_mantenimiento = array();
		for($i = 0; $i < count($lista_refacciones); $i++) {
			$query2 = $this->db->where('id_refaccion', $lista_refacciones[$i]->id)->get('refaccionmantenimiento');
			$lista_refaccionmantenimiento = $query2->result();

			for($j = 0; $j < count($lista_refaccionmantenimiento); $j++) {
				array_push($ids_mantenimiento, $lista_refaccionmantenimiento[$j]->id_mantenimiento);
			}
		}
		if (count($ids_mantenimiento) > 0 ) {
			if (isset($data['fecha_inicial']) && isset($data['fecha_final'])) {
				$condiciones = array(
					'fecha >=' => $data['fecha_inicial'],
					'fecha <=' => $data['fecha_final']
				);
				$query3 = $this->db->where_in('id', $ids_mantenimiento)
				->where($condiciones)->order_by('fecha', 'DESC')->get('mantenimientos');	
			} else {
				$query3 = $this->db->where_in('id', $ids_mantenimiento)->order_by('fecha', 'DESC')->get('mantenimientos');	
			}
		
		$lista = $query3->result();
		} else {
			$lista = [];
		}
		
		$respuesta = array(
	        'err' => FALSE,
	        'cuantos' => count($lista),
	        'lista' => $lista,
	        'proveedor' => $proveedor,
	        'err_code' => 'HTTP_OK'
	    );
		$this->response($respuesta);
	}



	public function index_delete() {
		$id = $this->uri->segment(2);
		if (!isset($id)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Es necesario el ID del numero',
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta);
			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}
		$respuesta = $this->Mantenimientos_model->delete($id);
		$this->response( $respuesta );
	}

	public function index_post() {
		$data = $this->post();
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
		$result = $this->Mantenimientos_model->set_datos($data);
		$respuesta = $result->insert();

		if ($respuesta['err']) {
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		} else {
			$this->response($respuesta);
		}

		$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
	}

	public function mantenimiento_get(){
		$id = $this->uri->segment(3);

		//Validacion del numero_id
		if (!isset($id)) {
			$respuesta = array(
				'err' => true,
				'mensaje' => 'Es necesario el ID del Ingreso',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		if (!is_numeric($id)) {
			$respuesta = array(
				'err' => false,
				'mensaje' => 'El ID debe ser numérico.',
				'result' => $id,
				'err_code' => 'HTTP_BAD_REQUEST'
			);
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);

			return;
		}

		$result = $this->Mantenimientos_model->get($id);

		if (isset($result)) {
			$unidad = $this->Unidades_model->get($result->id_unidad);
			$result->unidad = $unidad;
			$respuesta = array(
				'err' => false,
				'mensaje' => 'Registro cargado correctamente.',
				'result' => $result,
				'err_code' => 'HTTP_OK'
			);
			$this->response($respuesta);
		} else {

			$respuesta = array(
				'err' => true,
				'mensaje' => 'El registro ' . $id . ' no existe.',
				'result' => null,
				'err_code' => 'HTTP_NOT_FOUND'
			);
			$this->response($respuesta, RestController::HTTP_NOT_FOUND);
		}
	}

	public function index_put() {
        $id = $this->uri->segment(2);
		$anterior = $this->Mantenimientos_model->get($id);
		$data = $this->put();
		$data['id'] = $id;
		$this->load->library('form_validation');
		$this->form_validation->set_data($data);
		$obj = $this->Mantenimientos_model->set_datos( $data );
		$respuesta = $obj->update();
		if ($respuesta['err']) {
			$this->response($respuesta, RestController::HTTP_BAD_REQUEST);
		} else {
			$this->response($respuesta);
		}
	}
	
	public function upload_post(){
		
		$data = 'entro';
		$id = $this->uri->segment(3);
		$campo = $this->uri->segment(4);
		$mantenimiento = $this->Mantenimientos_model->get($id);



		if (!file_exists('./uploads/mantenimientos')) {
			mkdir('./uploads/mantenimientos', 0755);
		}
		if (!file_exists('./uploads/mantenimientos/Mantenimiento-'.$id)) {
			mkdir('./uploads/mantenimientos/Mantenimiento-'.$id, 0755);
		}

		if(count($_FILES) > 0 ){
			$config['upload_path'] = './uploads/mantenimientos/Mantenimiento-'.$id;
			$config['allowed_types'] = 'gif|jpg|jpeg|png|GIF|JPG|JPEG|PNG|pdf|PDF';
			$config['max_size'] = '0' ; 
			$config['max_width'] = '0' ; 
			$config['max_height'] = '0' ;
			$this->load->library('upload', $config);
			foreach ($_FILES as $nombre => $archivo) {
				if ( ! $this->upload->do_upload($nombre)){
					$error = array('error' => $this->upload->display_errors());
					$respuesta = array(
						'err' => true,
						'mensaje' => 'Ocurrio un error al subir los archivos',
						'errors' => $error,
					);
				}
				else{
					$data = array('upload_data' => $this->upload->data());
					if(!isset($mantenimiento->$campo)){
						$mantenimiento->$campo= $data['upload_data']['file_name'];
					}else{
						$ant_imgs = $mantenimiento->$campo;
						$mantenimiento->$campo = $ant_imgs . "," . $data['upload_data']['file_name'];
					}
					$result = $mantenimiento->update();
					$respuesta = array(
						'err' => false,
						'mensaje' => 'Subida de archivo correta',
						'update' => $result,
						'mantenimiento' => $mantenimiento,
						'err_code' => 'HTTP_OK'
					);
				}
			}

			$this->response($respuesta);
		}else{
			$this->response(array(
				'err'=> true, 
				'mensaje' => 'No selecciono ningun archivo', 
				'err_code' => 'HTTP_BAD_REQUEST'
			));
		}
	}


}