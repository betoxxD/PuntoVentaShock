<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require( APPPATH.'/libraries/RestController.php');
require( APPPATH.'/libraries/Format.php');

use chriskacerguis\RestServer\RestController;

class Operaciones extends RestController {

    public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('Nominas_model');
		$this->load->model('Clientes_model');
		$this->load->model('Choferes_model');
		$this->load->model('Unidades_model');
		$this->load->model('Direcciones_model');
	}

	public function calculonominachofer_post() {
		$data = $this->post();
		$id = $this->uri->segment(3);
		// $this->response($data);
		$query =  $this->db->select('* from controlservicios where dia_reserva between \''.$data['fecha_inicial'].'\' and \''.$data['fecha_final'].'\' and estado = \'Finalizado\' and id_chofer = '.$id)->get();
		$query2 = $this->db->select('count(cs.id) as res from controlservicios cs join choferes cf on cs.id_chofer = cf.id
			join diasinhabiles dias on dias.id_chofer = cf.id
			where cs.dia_reserva between \''.$data['fecha_inicial'].'\' and \''.$data['fecha_final'].'\' and 
			cs.estado = \'Finalizado\' and cs.dia_reserva  between dias.dia_inicio and dias.dia_final and cf.id = '.$id)->get();

		$query3 = $this->db->select('* from diasinhabiles where dia_inicio between \''.$data['fecha_inicial'].'\' and \''.$data['fecha_final'].'\' and dia_inicio between \''.$data['fecha_inicial'].'\' and \''.$data['fecha_final'].'\' and id_chofer = '.$id)->get();
		$query4 = $this->db->select('* from controlcombustible where  dia between \''.$data['fecha_inicial'].'\' and \''.$data['fecha_final'].'\'  and id_chofer = '.$id)->get();

		$unidad = $this->Unidades_model->getByChofer('1');
		$lista = $query->result();
		$fechas_inhabiles = $query3->result();
		$lista_gastoscombustible = $query4->result();
		$contadoHorario1 = 0;
		$contadoHorario2 = 0;
		$contadorInhabiles = 0;
		$contadorHabiles = 0;
		$gastos_diesel = 0;
		$total_combustible = 0;
		$kilometraje_recorrido = 0;
		$gastominimo_combustible = 0;
		$gastomaximo_combustible = 0;
		$promedio_combustible = 0;
		$bono = 0;

		if (isset($unidad)) {
			$gastominimo_combustible = $unidad->gastominimo_combustible;
			$gastomaximo_combustible = $unidad->gastomaximo_combustible;
		}

		$resultdos_fechas = array();
		for($i =0 ; $i < count($lista_gastoscombustible); $i++) {
			$gastos_diesel += $lista_gastoscombustible[$i]->tipo == 'Diesel' ? floatval($lista_gastoscombustible[$i]->gastos) : 0;
			$total_combustible += floatval($lista_gastoscombustible[$i]->gastos);
		}
		for($i = 0; $i < count($lista); $i++) {
			$kilometraje_recorrido += isset($lista[$i]->kilometraje_recorrido) ? floatval($lista[$i]->kilometraje_recorrido) : 0;
			
			if ($lista[$i]->tipo_corte == 1) {
				$contadoHorario1 ++;
			} else {
				$contadoHorario2 ++;
			}

			$esHabil = true;
			for ($j = 0; $j < count($fechas_inhabiles); $j++) {
				if ($this->check_in_range($fechas_inhabiles[$j]->dia_inicio, $fechas_inhabiles[$j]->dia_final,
					$lista[$i]->dia_reserva)) {
					$esHabil = false;
					$contadorInhabiles ++;
					$j = count($fechas_inhabiles);
				}
			}
			if ($esHabil) {
				$contadorHabiles ++;
			}
		}
		$promedio_combustible = floatval(floatval($gastos_diesel) / count($lista));
		$promedio_kilometros =  $kilometraje_recorrido / count($lista);
		$es_afavor = 'Si';
		if ($promedio_combustible >= floatval($gastomaximo_combustible)) {
			$bono = (floatval($promedio_combustible) - floatval($gastomaximo_combustible)) * count($lista);
			$es_afavor = 'No';
			$tipo_bono = 'Bajo';
		} else if ($promedio_combustible < floatval($gastominimo_combustible)) { 
			$bono = (floatval($gastominimo_combustible) - floatval($promedio_combustible)) * count($lista);
			$tipo_bono = 'Alto';
		} else {
			$tipo_bono = 'Medio';
			$bono = (floatval($gastomaximo_combustible) - floatval($promedio_combustible)) * count($lista);
		}

		$this->response(array(
			'err' => false,
			'total_servicios' => count($lista),
			'total_horario1' => $contadoHorario1,
			'total_horario2' => $contadoHorario2,
			'total_laborales' => $contadorHabiles,
			'total_inhabiles' => $contadorInhabiles,
			'lista' => $lista,
			'lista_gastoscombustible' => $lista_gastoscombustible,
			'fechas' => $query3->result(),
			'gastos_diesel' => $gastos_diesel,
			'total_combustible' => $total_combustible,
			'total_kilometros' => $kilometraje_recorrido,
			'promedio_combustible' =>  $promedio_combustible,
			'promedio_kilometros' =>  $promedio_kilometros,
			'unidad' => $unidad,
			'minimo' => $gastominimo_combustible,
			'maximo' => $gastomaximo_combustible,
			'bono' => $bono,
			'tipo_bono' => $tipo_bono,
			'es_afavor' => $es_afavor,
		));

	}

	public function check_in_range($fecha_inicio, $fecha_fin, $fecha){
	     $fecha_inicio = strtotime($fecha_inicio);
	     $fecha_fin = strtotime($fecha_fin);
	     $fecha = strtotime($fecha);
	     if(($fecha >= $fecha_inicio) && ($fecha <= $fecha_fin)) {
	         return true;
	     } else {
	         return false;
	     }
	}

	public function vigencialicencia_post() {
		$data = $this->post();
		$query1 = $this->db->select('id, vigencia_licencia')->where('status', 'Activo')->get('choferes');
		$lista_choferes = $query1->result();
		$fecha_actual = new DateTime($data['fecha']);
		$lista_resultados = array();
		for ($i = 0; $i < count($lista_choferes); $i++) {
			$vigencia = new DateTime($lista_choferes[$i]->vigencia_licencia);
			$diferencia =  $fecha_actual->diff($vigencia);
			if (($diferencia->days   == 30 
							||  $diferencia->days   == 23
							||  $diferencia->days   == 21
							||  $diferencia->days   <= 7) && $diferencia->invert == 0) {
					$obj = array(
						'fecha_actual' => $fecha_actual,
						'fecha_vigencia' => $vigencia,
						'diferencia' => $diferencia->days
					);
					array_push($lista_resultados, $obj);
			}
		}
		$this->response(array(
			'lista' => $lista_resultados
		));
	}

	public function fechaverificacion_post() {
		$data = $this->post();
		$query1 = $this->db->select('id, proxima_verificacion')->where('status', 'Activo')->get('unidades');
		$lista_unidades = $query1->result();
		$fecha_actual = new DateTime($data['fecha']);
		$lista_resultados = array();
		for ($i = 0; $i < count($lista_unidades); $i++) {
			$vigencia = new DateTime($lista_unidades[$i]->vigencia_licencia);
			$diferencia =  $fecha_actual->diff($vigencia);
			if (($diferencia->days   == 30 
							||  $diferencia->days   == 23
							||  $diferencia->days   == 21
							||  $diferencia->days   <= 7) && $diferencia->invert == 0) {
					$obj = array(
						'fecha_actual' => $fecha_actual,
						'fecha_vigencia' => $vigencia,
						'diferencia' => $diferencia->days
					);
					array_push($lista_resultados, $obj);
			}
		}
		$this->response(array(
			'lista' => $lista_resultados
		));
	}
	public function vencimientopoliza_post() {
		$data = $this->post();
		$query1 = $this->db->select('id, vencimiento_poliza')->where('status', 'Activo')->get('unidades');
		$lista_unidades = $query1->result();
		$fecha_actual = new DateTime($data['fecha']);
		$lista_resultados = array();
		for ($i = 0; $i < count($lista_unidades); $i++) {
			$vencimiento = new DateTime($lista_unidades[$i]->vencimiento_poliza);
			$diferencia =  $fecha_actual->diff($vencimiento);
			if (($diferencia->days   == 30 
							||  $diferencia->days   == 23
							||  $diferencia->days   == 21
							||  $diferencia->days   <= 7) && $diferencia->invert == 0) {
					$obj = array(
						'fecha_actual' => $fecha_actual,
						'fecha_vencimiento' => $vencimiento,
						'diferencia' => $diferencia->days
					);
					array_push($lista_resultados, $obj);
			}
		}
		$this->response(array(
			'lista' => $lista_resultados
		));
	}
	public function fechapago_post() {
		$data = $this->post();
		$fecha_actual = new DateTime($data['fecha']);
		$query1 = $this->db->select('id, fecha_pago')->
			where('(month(fecha_pago) = month(\''.$data['fecha'].'\') 
				or month(fecha_pago) = month(\''.$data['fecha'].'\') - 1
				or month(fecha_pago) = month(\''.$data['fecha'].'\') + 1)
				and year(fecha_pago) = year(\''.$data['fecha'].'\')')->get('egresos');
		$lista_egresos = $query1->result();
		$lista_resultados = array();
		for ($i = 0; $i < count($lista_egresos); $i++) {
			$vigencia = new DateTime($lista_egresos[$i]->fecha_pago);
			$diferencia =  $fecha_actual->diff($vigencia);
			if (($diferencia->days   == 10 
					||  $diferencia->days   == 7
					||  $diferencia->days   == 5
					||  $diferencia->days   == 3
					||  $diferencia->days   == 0
					) && $diferencia->invert == 0) {
			$obj = array(
				'fecha_actual' => $fecha_actual,
				'fecha_vigencia' => $vigencia,
				'diferencia' => $diferencia->days
			);
			array_push($lista_resultados, $obj);
			}
		}
		$this->response(array(
			'lista' => $lista_resultados
		));
	}

	public function cortenotas_post() {
		$data = $this->post();
		$fecha_actual = new DateTime($data['fecha']);
		$condiciones = array(
			'fecha' => $data['fecha'],
			'tipo_corte' => $data['tipo_corte']
		);
		$query1 = $this->db->where($condiciones)->get('cortesnotas');
		$this->response(array('lista' => $query1->resulst()));
	}

	public function cortecombustible_post() {
		$data = $this->post();
		$fecha_actual = new DateTime($data['fecha']);
		$condiciones = array(
			'fecha' => $data['fecha'],
			'tipo_corte' => $data['tipo_corte']
		);
		$query1 = $this->db->where($condiciones)->get('cortescombustible');
		$this->response(array('lista' => $query1->resulst()));
	}
	public function boleteracombustible_get() {
		$query = $this->db->get('generales');
		$data = $query->result();
		if (isset($data[0])) {
			$this->response(array(
				'err' => false,
				'result' => intval($data[0]->boletera_combustible) <= 100000
			));
		} else {
			$this->response(array(
				'err' => true,
				'mensaje' => 'no se encontro valor',
				'result' => false
			));
		}
	}

}