<?php

defined('BASEPATH') OR exit('No direct scrips access allowed');

class Mantenimientos_model extends CI_Model {
	public $id;
	public $id_unidad;
	public $id_solicitante;
	public $tipo_solicitante;
	public $letra_unidad;
	public $solicitud;
	public $fecha;
	public $alerta_prioridades;
	public $tipo_mantenimiento;
	public $fecha_realizacion;
	public $lugar_servicio;
	public $tipo_reparacion;
	public $evidencia_antesreparacion;
	public $evidencia_reparacion;
	public $consto_reparacion;
	public $evidencia_costo;
	public $estado;
	public $comentarios;

	public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function set_datos($data_cruda){
		foreach ($data_cruda as $nombre_campo => $valor_campo) {
			if (property_exists('Mantenimientos_model', $nombre_campo)) {
				$this->$nombre_campo = $valor_campo;
			}
		}
		return $this;
	}
	public function get($id) {
		$this->db->where(array('id' => $id));
		$query = $this->db->get('mantenimientos');
		$row = $query->custom_row_object(0, 'Mantenimientos_model');
		if (isset($row)) {
			$row->id = intval($row->id);
		}
		return $row;
	}
	public function insert() {
		$query = $this->db->get_where('mantenimientos', array('id' => $this->id));
		$producto = $query->row();

		if (isset($producto)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'El producto ya está registrado.',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			return $respuesta;
		}
		$hecho = $this->db->insert('mantenimientos', $this);
		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro insertado correctamente',
				'id' => $this->db->insert_id(),
				'err_code' => 'HTTP_OK'
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al insertar.',
				'error' => $this->db->error(),
				'err_code' => 'HTTP_INTERNAL_SERVER_ERROR'
			);
		}
		return $respuesta;
	}

	public function update() {
		$this->db->where('id', $this->id);
		$hecho = $this->db->update('mantenimientos', $this);
		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro actualizado correctamente',
				'id' => $this->id
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al actualizar.',
				'error' => $this->db->error()
			);
		}
		return $respuesta;
	}

	public function delete($id) {
    	$this->db->where('id', $id);
		$query = $this->db->delete('mantenimientos');
    	$res = array(
            'err' => false,
            'mensaje' => 'Dato eliminado correctamente.',
            'result' => $query);
		
		return $res;

    }




}	