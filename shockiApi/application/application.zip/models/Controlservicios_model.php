<?php

defined('BASEPATH') OR exit('No direct scrips access allowed');

class Controlservicios_model extends CI_Model {
	public $id;
    public $id_cliente;
    public $id_direccion;
    public $id_corte;
    public $dia_peticion;
    public $hora_peticion;
    public $dia_reserva;
    public $hora_reserva;
    public $suministro;
    public $costo_servicio;
    public $forma_pago_servicio;
    public $id_chofer;
    public $id_unidad;
    public $hora_atencion;
    public $hora_entrada;
    public $hora_salida;
    // public $carga_gasolina;
    // public $carga_diesel;
	// public $evidencia_cargagasolina;
    // public $evidencia_cargadiesel;
    public $tipo_corte;
    public $gastos;
    public $evidencia_gastos;
	public $forma_pago_gastos;
    public $estado;
	public $pozo_carga;
	public $cantidad_cargada;
    public $kilometraje_recorrido;

	public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function set_datos($data_cruda){
		foreach ($data_cruda as $nombre_campo => $valor_campo) {
			if (property_exists('Controlservicios_model', $nombre_campo)) {
				$this->$nombre_campo = $valor_campo;
			}
		}
		return $this;
	}
	public function get($id) {
		$this->db->where(array('id' => $id));
		$query = $this->db->get('controlservicios');
		$row = $query->custom_row_object(0, 'Controlservicios_model');
		if (isset($row)) {
			$row->id = intval($row->id);
		}
		return $row;
	}

	public function insert() {
		$query = $this->db->get_where('controlservicios', array('id' => $this->id));
		$producto = $query->row();

		if (isset($producto)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'El producto ya está registrado.',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			return $respuesta;
		}
		$hecho = $this->db->insert('controlservicios', $this);
		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro insertado correctamente',
				'id' => $this->db->insert_id(),
				'err_code' => 'HTTP_OK'
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al insertar.',
				'error' => $this->db->error(),
				'err_code' => 'HTTP_INTERNAL_SERVER_ERROR'
			);
		}
		return $respuesta;
	}

	public function update() {
		$this->db->where('id', $this->id);
		$hecho = $this->db->update('controlservicios', $this);
		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro actualizado correctamente',
				'id' => $this->id
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al actualizar.',
				'error' => $this->db->error()
			);
		}
		return $respuesta;
	}

	public function delete($id) {
    	$this->db->where('id', $id);
		$query = $this->db->delete('controlservicios');
    	$res = array(
            'err' => false,
            'mensaje' => 'Dato eliminado correctamente.',
            'result' => $query);
		
		return $res;

    }




}	