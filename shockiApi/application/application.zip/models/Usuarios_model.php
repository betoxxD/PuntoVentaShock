<?php

defined('BASEPATH') OR exit('No direct scrips access allowed');

class Usuarios_model extends CI_Model {
	public $id;
	public $nombre;
	public $apellidos;
	public $direccion;
	public $email;
	public $password;
	public $img;
	public $role;
    public $permisos;

	public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function set_datos($data_cruda){
		foreach ($data_cruda as $nombre_campo => $valor_campo) {
			if (property_exists('Usuarios_model', $nombre_campo)) {
				$this->$nombre_campo = $valor_campo;
			}
		}
		return $this;
	}
	public function get($id) {
		$this->db->where(array('id' => $id));
		$query = $this->db->get('usuarios');
		$row = $query->custom_row_object(0, 'Usuarios_model');
		if (isset($row)) {
			$row->id = intval($row->id);
		}
		return $row;
	}
	public function insert() {
		$query = $this->db->get_where('usuarios', array('id' => $this->id));
		$producto = $query->row();

		if (isset($producto)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'El producto ya está registrado.',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			return $respuesta;
		}
		$this->password =  hash('sha512', $this->password);
		$hecho = $this->db->insert('usuarios', $this);
		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro insertado correctamente',
				'id' => $this->db->insert_id(),
				'err_code' => 'HTTP_OK'
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al insertar.',
				'error' => $this->db->error(),
				'err_code' => 'HTTP_INTERNAL_SERVER_ERROR'
			);
		}
		return $respuesta;
	}

	public function update() {
		$this->db->where('id', $this->id);
		if(strlen($this->password)<30){
			$this->password =  hash('sha512', $this->password);
		}
		$hecho = $this->db->update('usuarios', $this);

		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro actualizado correctamente',
				'id' => $this->id
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al actualizar.',
				'error' => $this->db->error()
			);
		}
		return $respuesta;
	}


	public function delete($id) {
    	$this->db->where('id', $id);
		$query = $this->db->delete('usuarios');
    	$res = array(
            'err' => false,
            'mensaje' => 'Dato eliminado correctamente.',
            'result' => $query);
	
		return $res;

	}

	/** Funcion Login */
	
	public function login($email, $password){

		$password = hash('sha512', $password);
        $this->db->where(array('email' => $email, 'password' => $password ));
		$query = $this->db->get('usuarios');

		$row = $query->custom_row_object(0, 'Usuarios_model');

		if (isset($row)) {
            $row->id = intval($row->id);
            $row->password = '';
        }
        
		return $row;
    }




}	