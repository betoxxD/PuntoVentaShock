<?php

defined('BASEPATH') OR exit('No direct scrips access allowed');

class Unidades_model extends CI_Model {
	public $id;
	public $id_chofer;
	public $placas;
	public $fotografia;
	public $capacidad;
	public $tiempo_llenado;
	public $modelo;
	public $year;
	public $motor;
	public $ejes;
	public $numero_poliza;
	public $vencimiento_poliza;
	public $fecha_verificacion;
	public $proxima_verificacion;
	public $letra_folio;
	public $tarjeta_circulacion;
	public $evidencia_tarjeta;
	public $gastomaximo_combustible;
	public $gastominimo_combustible;
	public $status;
	public $accion;

	public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function set_datos($data_cruda){
		foreach ($data_cruda as $nombre_campo => $valor_campo) {
			if (property_exists('Unidades_model', $nombre_campo)) {
				$this->$nombre_campo = $valor_campo;
			}
		}
		return $this;
	}
	public function get($id) {
		$this->db->where(array('id' => $id));
		$query = $this->db->get('unidades');
		$row = $query->custom_row_object(0, 'Unidades_model');
		if (isset($row)) {
			$row->id = intval($row->id);
		}
		return $row;
	}

	public function getByChofer($id) {
		$this->db->where(array('id_chofer' => $id));
		$query = $this->db->get('unidades');
		$row = $query->custom_row_object(0, 'Unidades_model');
		if (isset($row)) {
			$row->id = intval($row->id);
		}
		return $row;
	}

	public function insert() {
		$query = $this->db->get_where('unidades', array('id' => $this->id));
		$producto = $query->row();

		if (isset($producto)) {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'El producto ya está registrado.',
				'err_code' => 'HTTP_BAD_REQUEST'
			);

			return $respuesta;
		}
		$hecho = $this->db->insert('unidades', $this);
		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro insertado correctamente',
				'id' => $this->db->insert_id(),
				'err_code' => 'HTTP_OK'
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al insertar.',
				'error' => $this->db->error(),
				'err_code' => 'HTTP_INTERNAL_SERVER_ERROR'
			);
		}
		return $respuesta;
	}

	public function update() {
		$this->db->where('id', $this->id);
		$hecho = $this->db->update('unidades', $this);
		if ($hecho) {
			$respuesta = array(
				'err' => FALSE,
				'mensaje' => 'Registro actualizado correctamente',
				'id' => $this->id
			);
		} else {
			$respuesta = array(
				'err' => TRUE,
				'mensaje' => 'Error al actualizar.',
				'error' => $this->db->error()
			);
		}
		return $respuesta;
	}

	public function delete($id) {
    	$this->db->where('id', $id);
		$query = $this->db->delete('unidades');
    	$res = array(
            'err' => false,
            'mensaje' => 'Dato eliminado correctamente.',
            'result' => $query);
		
		return $res;

    }




}	